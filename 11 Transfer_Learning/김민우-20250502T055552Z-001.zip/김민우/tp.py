import effdet.efficientdet
print(dir(effdet.efficientdet))

